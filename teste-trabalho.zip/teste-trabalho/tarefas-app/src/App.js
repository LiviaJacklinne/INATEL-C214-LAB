import React from 'react';
import './App.css';
// import ListaTarefas from './components/ListaTarefas';
import ListaTarefas from './components/ListaTarefa';

function App() {
  return (
    <div className="App">
      <ListaTarefas />
    </div>
  );
}

export default App;
